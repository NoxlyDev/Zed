# Zed untuk Android (arm64)

Isi paket ini:

- `overlay/` : file baru (crate `gpui_android`, crate `zed_android`, proyek Gradle `android/`, workflow `.github/workflows/android-apk.yml`)
- `modified-files.patch` : perubahan pada file Zed yang sudah ada (Cargo.toml, Cargo.lock, gpui.rs, gpui_platform, .gitignore)
- `apply.sh` : menerapkan keduanya ke root repo Zed

## Cara pakai
1. `./apply.sh /path/ke/zed-main`
2. Commit dan push ke repo GitHub Anda.
3. Tab **Actions** -> **Android APK** -> **Run workflow**. APK muncul di Artifacts (`zed-android-arm64.apk`).
4. Install APK di HP (arm64, Android 8.0+).

## Setup di HP (sekali saja)
1. Install **Termux** dari F-Droid/GitHub (bukan Play Store), lalu di Termux:
   ```
   pkg install rust
   echo "allow-external-apps=true" >> ~/.termux/termux.properties
   termux-setup-storage
   ```
   Tutup Termux sepenuhnya lalu buka lagi.
2. Buka app Zed, tap **Grant** (All files access) dan izinkan, lalu buka ulang app.
3. Tap **Run ▶**, izinkan permission Termux RUN_COMMAND, tap **Run ▶** lagi.

Proyek berada di `/sdcard/ZedAndroid/hello`, target build di `~/.cache/zed-android/target` (Termux).

## Status verifikasi
- `cargo check --target aarch64-linux-android -p zed_android` lolos (Rust 1.100.0) dengan GPUI asli.
- BELUM terbukti: link `.so`, perakitan APK, dan jalan di perangkat. Itu yang diuji workflow.
- Rust toolchain repo (1.98.1) belum dicoba; saya memakai 1.100.0.
